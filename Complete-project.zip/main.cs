using System;
using System.Globalization;
using System.Text.RegularExpressions;

class Program {
  public static void Main (string[] args) {
    string status = "running";
    while (status != "ended"){
      bool check = false;    
      Console.WriteLine ("Enter the number for the language direction you want translating :");
      Console.WriteLine("1 for python to c#");
      Console.WriteLine("2 for c# to python");
      Console.WriteLine("3 to quit the program");
      Console.WriteLine();
      int Language = Convert.ToInt32(Console.ReadLine ());
      Console.WriteLine();
      while (check == false){
        if (Language == 1){
          Python_to_Csharp();
          check = true;
        }else if (Language == 2){
          Csharp_to_Python();
          check = true;
        }else if (Language == 3){
          Console.WriteLine ("You have ended the program. Goodbye.");
          check = true;
          status = "ended";
        }else{
          Console.WriteLine("The input is not a suitable language option. Re-enter the number:");
          Language = Convert.ToInt32(Console.ReadLine ());
          check = false;
        }
      }
    
    }
  }

  //C# to python translator
  public static void Csharp_to_Python () {
    Console.WriteLine ("Enter the code to be translated:");
    string OriginalCode = Console.ReadLine ();
    //Console.WriteLine (OriginalCode);
    /* Defining loop variables*/
    while (OriginalCode.Length<20){
      Console.WriteLine("There is an error within the input line. Please re-enter the original code");
      OriginalCode = Console.ReadLine ();
    }
    string OutComparison = Convert.ToString(OriginalCode[0]) +              Convert.ToString(OriginalCode[1]);
    //Console.WriteLine (OutComparison);

    /*establishing first 1 characters of each python code*/
    string InComparison = Convert.ToString(OriginalCode[OriginalCode.Length - 12]) + Convert.ToString(OriginalCode[OriginalCode.Length - 11]);

    /*identifying code and converting*/
    if (OutComparison == "Co"){
      char LineCheck = OriginalCode[13];
      //LineCheck is used to determine whether input is Write or WriteLine
      if (LineCheck == 'L'){
        /* changing WriteLine statement*/
        string NewCode = "print" + OriginalCode.Substring(17);
        Console.WriteLine (NewCode.Remove(NewCode.Length - 1)+ "\n");
    } else {
      /* changing Write statement*/
        string NewCode = "print" + OriginalCode.Substring(13);
        Console.WriteLine (NewCode.Remove(NewCode.Length - 1)+ " #there is no direct equivalent at this level in python" +"\n");
      } 
    }else if (InComparison == "Re"){
      /* changing ReadLine statement*/
      /** ROSEMARY you need to cycle through the line, to work out the length of the variable name. It needs to then go at the front of the string to return -found a solution* I start by removing the initialisation of the data type. Once this is done, I read from the end, removing the "Console.ReadLine() ;" from the string.*/
      
      if (OutComparison == "st"){
        /*string - string*/
        string NewCode = OriginalCode.Substring(7);
        Console.WriteLine (NewCode.Remove(NewCode.Length - 20) + " input()\n");
      } else if (OutComparison == "ch"){
        /*character - char*/
        string NewCode = OriginalCode.Substring(5);
        Console.WriteLine (NewCode.Remove(NewCode.Length - 20) + " input()               [0]\n");
      } else if (OutComparison == "in"){
        /*integer - int*/
        string NewCode = OriginalCode.Substring(4);
        Console.WriteLine (NewCode.Remove(NewCode.Length - 20) + "                       int(input())\n");
      } else if (OutComparison == "fl"){
        /*float - float*/
        string NewCode = OriginalCode.Substring(6);
        Console.WriteLine (NewCode.Remove(NewCode.Length - 20) + "                       float(input())\n");
      } else if (OutComparison == "bo"){
        /*boolean - bool*/
        string NewCode = OriginalCode.Substring(5);
        Console.WriteLine (NewCode.Remove(NewCode.Length - 20) + "                       bool(input())\n");
      }
    } else{
        Console.WriteLine ("#This line either contains an error or is beyond the         scope of this program."+ OriginalCode +"\n");
        /*The above statement will be true when code is converted to function as I will check for loops and ends of loops before checking for input or output statements*/
    }
  }

  //C# from python translator
  public static void Python_to_Csharp () {
    
    Console.WriteLine ("Enter the code to be translated:");
    string VariableName = "";
    string OriginalCode = Console.ReadLine ();
    /* Defining loop variables*/
    string OutComparison = Convert.ToString(OriginalCode[0]) + Convert.ToString(OriginalCode[1]) + Convert.ToString(OriginalCode[2]) + Convert.ToString(OriginalCode[3]) + Convert.ToString(OriginalCode[4]) + Convert.ToString(OriginalCode[5]);
    char InComparison = OriginalCode[OriginalCode.Length - 1]; //This is the last character.
    //Console.WriteLine (comparison);


    if (OutComparison == "print "|OutComparison == "print("){
      //IT IS AN OUTPUT
      /* changing output statement*/
      /*The "\n" was added on 13/10 when I realised the code would store into a variable to be printed as one later, requiring the lines to be accounted for*/
      Console.WriteLine ("Console.WriteLine " + OriginalCode.Substring(5) + ';' + "\n");
    }else{
      //IT IS AN INPUT
      /*determine length of variable name*/
      for(int index = 0; index < OriginalCode.Length; index++){
        if(OriginalCode[index] == '='){
          //This is to determine the length of the variable name in this given line. This will allow further numerical data to be accurate as python doesn't require definitions for variables.
          int EndIndex = index;
          index = OriginalCode.Length; //breaks the loop
        }else{
          VariableName = VariableName + OriginalCode[index]; //adds the character being checked to the variable name
          // VariableName stores up to character before = sign
        }
      }
      if(InComparison == ']'){
        /*THIS IS CHARACTER CASE*/
        Console.WriteLine("char " + VariableName + "= Console.ReadLine ();" + "\n");

      }else{
        //THIS IS NON CHARACTER CASE OR SYNTAX ERROR
        string PatternInt = @"\s*\u0069\u006E\u0074\s*\u0028";// int (
        Regex rgx_int = new Regex(PatternInt);

        string PatternFloat = @"\s*\u0066\u006C\u006F\u0061\u0074\s*\u0028";// float (
        Regex rgx_float = new Regex(PatternFloat);

        string PatternBool = @"\s*\u0062\u006F\u006F\u006C\s*\u0028";// bool ( 
        Regex rgx_bool = new Regex(PatternBool);

        string PatternStr = @"\s*\u0073\u0074\u0072\s*\u0028";// str (
        Regex rgx_str = new Regex(PatternStr);

        string PatternGen = @"\s*\u0069\u006E\u0070\u0075\u0074\s*\u0028";// input (
        Regex rgx_gen = new Regex(PatternGen);
        //PatternGen and rgx_gen for generic

        //comparison between input code and python input codes
        if (rgx_int.IsMatch(OriginalCode, VariableName.Length)){
          Console.Write(""/*CONTENTS BETWEEN INPUT BRACKETS*/);
          Console.WriteLine("int " + VariableName + "= Console.ReadLine ();" + "\n");

        }else if (rgx_float.IsMatch(OriginalCode, VariableName.Length)){
          Console.Write(""/*CONTENTS BETWEEN INPUT BRACKETS*/);
          Console.WriteLine("float " + VariableName + "= Console.ReadLine ();" + "\n");


        }else if (rgx_bool.IsMatch(OriginalCode, VariableName.Length)){
          Console.Write(""/*CONTENTS BETWEEN INPUT BRACKETS*/);
          Console.WriteLine("bool " + VariableName + "= Console.ReadLine ();" + "\n");

        }else if (rgx_str.IsMatch(OriginalCode, VariableName.Length)){
          Console.Write(""/*CONTENTS BETWEEN INPUT BRACKETS*/);
          Console.WriteLine("string " + VariableName + "= Console.ReadLine ();" + "\n");

        }else if (rgx_gen.IsMatch(OriginalCode, VariableName.Length)){
          Console.Write(""/*CONTENTS BETWEEN INPUT BRACKETS*/);
          Console.WriteLine("string " + VariableName + "= Console.ReadLine ();" + "\n");

        }else{
          Console.WriteLine("ERROR" + "\n");
        }
      }
    }
  }
}