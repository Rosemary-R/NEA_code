using System;

class Program {
  public static void Main (string[] args) {
    Csharp_to_Python();
  }
  public static void Csharp_to_Python () {
    Console.WriteLine ("Enter the code to be translated:");
    string OriginalCode = Console.ReadLine ();
    //Console.WriteLine (OriginalCode);
    /* Defining loop variables*/
    string OutComparison = Convert.ToString(OriginalCode[0]) + Convert.ToString(OriginalCode[1]);
    //Console.WriteLine (OutComparison);

    /*establishing first 1 characters of each python code*/
    string InComparison = Convert.ToString(OriginalCode[OriginalCode.Length - 12]) + Convert.ToString(OriginalCode[OriginalCode.Length - 11]);

    /*identifying code and converting*/
    if (OutComparison == "Co"){
      char LineCheck = OriginalCode[13];
      //LineCheck is used to determine whether input is Write or WriteLine
      if (LineCheck == 'L'){
        /* changing WriteLine statement*/
        string NewCode = "print" + OriginalCode.Substring(17);
        Console.WriteLine (NewCode.Remove(NewCode.Length - 1)+ "\n");
    } else {
      /* changing Write statement*/
        string NewCode = "print" + OriginalCode.Substring(13);
        Console.WriteLine (NewCode.Remove(NewCode.Length - 1)+ "  #there is no direct equivalent at this level in python" +"\n");
      } 
    }else if (InComparison == "Re"){
      /* changing ReadLine statement*/
      /** ROSEMARY you need to cycle through the line, to work out the length of the variable name. It needs to then go at the front of the string to return -found a solution* I start by removing the initialisation of the data type. Once this is done, I read from the end, removing the "Console.ReadLine() ;" from the string.*/
      
      if (OutComparison == "st"){
        /*string - string*/
        string NewCode = OriginalCode.Substring(7);
        Console.WriteLine (NewCode.Remove(NewCode.Length - 20) + "input()\n");
      } else if (OutComparison == "ch"){
        /*character - char*/
        string NewCode = OriginalCode.Substring(5);
        Console.WriteLine (NewCode.Remove(NewCode.Length - 20) + "input()[0]\n");
      } else if (OutComparison == "in"){
        /*integer - int*/
        string NewCode = OriginalCode.Substring(4);
        Console.WriteLine (NewCode.Remove(NewCode.Length - 20) + "int(input())\n");
      } else if (OutComparison == "fl"){
        /*float - float*/
        string NewCode = OriginalCode.Substring(6);
        Console.WriteLine (NewCode.Remove(NewCode.Length - 20) + "float(input())\n");
      } else if (OutComparison == "bo"){
        /*boolean - bool*/
        string NewCode = OriginalCode.Substring(5);
        Console.WriteLine (NewCode.Remove(NewCode.Length - 20) + "bool(input())\n");
      }
    } else{
      Console.WriteLine ("#This line either contains an error or is beyond the scope of this program."+"\n");
      /*The above statement will be true when code is converted to function as I will check for loops and ends of loops before checking for input or output statements*/
    }
  }
}