using System;
using System.Globalization;
using System.Text.RegularExpressions;

class Program {
  public static void Main (string[] args) {
    // Define the regular expression pattern.
    string pattern; 
    pattern = @"\s*\u0069\u006E\u0074\s*\u0028";//any num of spaces + int
    string pattern2 = @"\s*\u0062\u006F\u006F\u006C\s*\u0028";//any num of spaces + b
    // Define an integer variable to check it will work with VariableName
    int start = 1;
    Regex rgx1 = new Regex(pattern);
    Regex rgx2 = new Regex(pattern2);

    // Define some test strings.
    string[] tests = { "= bool(input())", "= int(input())", "  bool(input(Enter number))", "pony", "abacas", "mein", "peel", "=int(input())", "banana", "=     int(input())" };

    // Check each test string against the regular expression.
    foreach (string test in tests)
    {
        if (rgx1.IsMatch(test, start)){
          Console.WriteLine("{0} is an integer input", test);
          Console.WriteLine();
        }else if (rgx2.IsMatch(test, start)){
          Console.WriteLine("{0} is a boolean input", test);
          Console.WriteLine('b');
        }else{
          Console.WriteLine("{0} is not an input", test);
        }
    }
  }
}