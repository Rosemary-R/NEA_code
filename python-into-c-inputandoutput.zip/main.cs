using System;
using System.Globalization;
using System.Text.RegularExpressions;

class Program {
  public static void Main (string[] args) {
    Python_to_Csharp();
  }
  public static void Python_to_Csharp () {
    
    Console.WriteLine ("Enter the code to be translated:");
    string VariableName = "";
    string OriginalCode = Console.ReadLine ();
    /* Defining loop variables*/
    string OutComparison = Convert.ToString(OriginalCode[0]) + Convert.ToString(OriginalCode[1]) + Convert.ToString(OriginalCode[2]) + Convert.ToString(OriginalCode[3]) + Convert.ToString(OriginalCode[4]) + Convert.ToString(OriginalCode[5]);
    char InComparison = OriginalCode[OriginalCode.Length - 1]; //This is the last character.
    //Console.WriteLine (comparison);


    if (OutComparison == "print "|OutComparison == "print("){
      //IT IS AN OUTPUT
      /* changing output statement*/
      /*The "\n" was added on 13/10 when I realised the code would store into a variable to be printed as one later, requiring the lines to be accounted for*/
      Console.WriteLine ("Console.WriteLine " + OriginalCode.Substring(5) + ';' + "\n");
    }else{
      //IT IS AN INPUT
      /*determine length of variable name*/
      for(int index = 0; index < OriginalCode.Length; index++){
        if(OriginalCode[index] == '='){
          //This is to determine the length of the variable name in this given line. This will allow further numerical data to be accurate as python doesn't require definitions for variables.
          int endIndex = index;
          index = OriginalCode.Length; //breaks the loop
        }else{
          VariableName = VariableName + OriginalCode[index]; //adds the character being checked to the variable name
          // VariableName stores up to character before = sign
        }
      }
      if(InComparison == ']'){
        /*THIS IS CHARACTER CASE*/
        Console.WriteLine("char " + VariableName + "= Console.ReadLine ();" + "\n");

      }else{
        //THIS IS NON CHARACTER CASE OR SYNTAX ERROR
        string PatternInt = @"\s*\u0069\u006E\u0074\s*\u0028";// int (
        Regex rgx_int = new Regex(PatternInt);

        string PatternFloat = @"\s*\u0066\u006C\u006F\u0061\u0074\s*\u0028";// float (
        Regex rgx_float = new Regex(PatternFloat);

        string PatternBool = @"\s*\u0062\u006F\u006F\u006C\s*\u0028";// bool ( 
        Regex rgx_bool = new Regex(PatternBool);

        string PatternStr = @"\s*\u0073\u0074\u0072\s*\u0028";// str (
        Regex rgx_str = new Regex(PatternStr);

        string PatternGen = @"\s*\u0069\u006E\u0070\u0075\u0074\s*\u0028";// input (
        Regex rgx_gen = new Regex(PatternGen);
        //PatternGen and rgx_gen for generic

        //comparison between input code and python input codes
        if (rgx_int.IsMatch(OriginalCode, VariableName.Length)){
          Console.Write(""/*CONTENTS BETWEEN INPUT BRACKETS*/);
          Console.WriteLine("int " + VariableName + "= Console.ReadLine ();" + "\n");

        }else if (rgx_float.IsMatch(OriginalCode, VariableName.Length)){
          Console.Write(""/*CONTENTS BETWEEN INPUT BRACKETS*/);
          Console.WriteLine("float " + VariableName + "= Console.ReadLine ();" + "\n");


        }else if (rgx_bool.IsMatch(OriginalCode, VariableName.Length)){
          Console.Write(""/*CONTENTS BETWEEN INPUT BRACKETS*/);
          Console.WriteLine("bool " + VariableName + "= Console.ReadLine ();" + "\n");

        }else if (rgx_str.IsMatch(OriginalCode, VariableName.Length)){
          Console.Write(""/*CONTENTS BETWEEN INPUT BRACKETS*/);
          Console.WriteLine("string " + VariableName + "= Console.ReadLine ();" + "\n");

        }else if (rgx_gen.IsMatch(OriginalCode, VariableName.Length)){
          Console.Write(""/*CONTENTS BETWEEN INPUT BRACKETS*/);
          Console.WriteLine("string " + VariableName + "= Console.ReadLine ();" + "\n");

        }else{
          Console.WriteLine("ERROR" + "\n");
        }
      }
    }
  }
}